<!DOCTYPE html>
<html lang="zh-HK">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>一封俾你嘅訊息 💌</title>
<style>
body{
    margin:0;
    height:100vh;
    overflow:hidden;
    display:flex;
    justify-content:center;
    align-items:center;
    background-color:#ffd6e7;
    background-image:
      radial-gradient(white 2px, transparent 2px);
    background-size:30px 30px;
    font-family:"Microsoft JhengHei",sans-serif;
}

.card{
    background:white;
    padding:30px;
    border-radius:20px;
    text-align:center;
    width:320px;
    box-shadow:0 10px 30px rgba(0,0,0,0.15);
}

h2{
    color:#ff69a6;
}

button{
    background:#ff8fb8;
    border:none;
    color:white;
    padding:12px 25px;
    border-radius:999px;
    font-size:16px;
    cursor:pointer;
}

button:hover{
    transform:scale(1.05);
}

#messageArea{
    display:none;
    position:absolute;
    inset:0;
}

.popup{
    position:absolute;
    background:white;
    padding:12px 18px;
    border-radius:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.15);
    animation:floatUp 5s linear forwards;
    font-size:18px;
    color:#ff5c99;
}

@keyframes floatUp{
    0%{
        opacity:0;
        transform:translateY(50px);
    }
    20%{
        opacity:1;
    }
    100%{
        opacity:0;
        transform:translateY(-250px);
    }
}
</style>

</head>

<body>

<div class="card" id="startCard">
    <h2>💌 你收到一封訊息</h2>
    <p>想唔想打開呀？</p>
    <button onclick="startMessages()">打開 ✨</button>
</div>

<div id="messageArea"></div>

<script>

const messages = [
"你好得意吖 ♡",
"你今日已經做得好好啦^",
"有人好珍惜你㗎♡´･ᴗ･`♡ ",
"記得對自己溫柔啲 💕",
"你嘅存在好重要 ( ˘ ³˘)♥︎",
"你值得被愛♥︎♡︎",
"希望你日日都開心❣︎♥︎",
"唔開心嘅日子都會過去㗎 (•̀ᴗ•́)و",
"你比自己想像中更加叻 ʕ•ᴥ•ʔ",
"多謝你一直努力 💌"
];

function startMessages(){
    document.getElementById("startCard").style.display="none";
    document.getElementById("messageArea").style.display="block";

    setInterval(()=>{
        const msg=document.createElement("div");
        msg.className="popup";

        msg.innerText=
          messages[Math.floor(Math.random()*messages.length)];

        msg.style.left=Math.random()*80+10+"%";
        msg.style.top=Math.random()*70+20+"%";

        document.getElementById("messageArea").appendChild(msg);

        setTimeout(()=>{
            msg.remove();
        },5000);

    },700);
}
</script>

</body>
</html>
:::

